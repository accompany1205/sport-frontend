import { PageView } from "layout/PageView";

export function EmptyPage() {
  return <PageView>Empty</PageView>;
}
